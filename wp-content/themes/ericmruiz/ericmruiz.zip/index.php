<?php get_header() ?>
<div class="content">
	<?php get_template_part('loop', 'index') ?>
</div>

<?php get_footer() ?>
