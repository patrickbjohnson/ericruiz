<?php get_header(); ?>
<div id="page-content">
	<?php get_template_part('loop', 'page'); ?>
</div>
<?php get_footer(); ?>
