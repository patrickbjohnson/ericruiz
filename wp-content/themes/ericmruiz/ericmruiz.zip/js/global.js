$(document).ready(function(){
	console.log('welcome to this site!');
});