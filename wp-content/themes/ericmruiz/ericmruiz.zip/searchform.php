<<<<<<< HEAD
<form action="<?php bloginfo('siteurl'); ?>" class="form form-search">
	<div class="form-row">
		<label for="search-input" class="sr-only">Search</label>
		<input class="form-control" type="text" placeholder="Search">
		<button class="btn">Submit</button>
	</div>
</form>
=======
<form action="<?php bloginfo('siteurl'); ?>" class="search-form">
    <div class="input-wrap search">
        <label for="input-s" class="screen-reader-text">Search for:</label>
        <input type="search" id="input-s" name="s" />
    </div>
    <div class="input-wrap submit">
        <input type="submit" value="Search" class="button" />
	</div>
</form>
>>>>>>> ba935a77e8cb3b50364ca36f1ceddc6345666780
