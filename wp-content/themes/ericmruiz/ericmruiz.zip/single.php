<?php get_header(); ?>
<div id="page-content">
	<?php get_template_part('blog-article', 'single'); ?>
</div>
<?php get_footer(); ?>
